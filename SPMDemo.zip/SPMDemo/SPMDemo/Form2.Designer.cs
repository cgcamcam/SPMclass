﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SPMDemo
{
    partial class Form2: Form //create new project screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.projectNameDataBox = new System.Windows.Forms.TextBox();
            this.EnterProjectLabel = new System.Windows.Forms.Label();
            this.OwnerNameDataBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Create = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // projectNameDataBox
            // 
            this.projectNameDataBox.Location = new System.Drawing.Point(317, 127);
            this.projectNameDataBox.Name = "projectNameDataBox";
            this.projectNameDataBox.Size = new System.Drawing.Size(100, 20);
            this.projectNameDataBox.TabIndex = 0;
            this.projectNameDataBox.TextChanged += new System.EventHandler(this.projectNameDataBox_TextChanged);
            // 
            // EnterProjectLabel
            // 
            this.EnterProjectLabel.AutoSize = true;
            this.EnterProjectLabel.Location = new System.Drawing.Point(314, 102);
            this.EnterProjectLabel.Name = "EnterProjectLabel";
            this.EnterProjectLabel.Size = new System.Drawing.Size(111, 13);
            this.EnterProjectLabel.TabIndex = 1;
            this.EnterProjectLabel.Text = "Enter Name of Project";
            this.EnterProjectLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // OwnerNameDataBox
            // 
            this.OwnerNameDataBox.Location = new System.Drawing.Point(317, 175);
            this.OwnerNameDataBox.Name = "OwnerNameDataBox";
            this.OwnerNameDataBox.Size = new System.Drawing.Size(100, 20);
            this.OwnerNameDataBox.TabIndex = 2;
            this.OwnerNameDataBox.TextChanged += new System.EventHandler(this.OwnerNameDataBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(316, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Enter Name of Owner";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Create
            // 
            this.Create.Location = new System.Drawing.Point(331, 247);
            this.Create.Name = "Create";
            this.Create.Size = new System.Drawing.Size(75, 23);
            this.Create.TabIndex = 4;
            this.Create.Text = "Create";
            this.Create.UseVisualStyleBackColor = true;
            this.Create.Click += new System.EventHandler(this.Create_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Create);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.OwnerNameDataBox);
            this.Controls.Add(this.EnterProjectLabel);
            this.Controls.Add(this.projectNameDataBox);
            this.Name = "Form2";
            this.Text = "Create Project";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox projectNameDataBox;
        private Label EnterProjectLabel;
        private TextBox OwnerNameDataBox;
        private Label label2;
        private Button Create;
    }
}